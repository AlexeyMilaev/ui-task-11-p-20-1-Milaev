﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UI_PR_TASK11_Milaev_P201.Core;

namespace UI_PR_TASK11_Milaev_P201;
/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        var products = GetProducts();

        if(products.Count > 0)
        {
            ListViewProducts.ItemsSource = products;
        }


    }
    private List<Product> GetProducts()
    {
        return new List<Product>() {
        new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
        new Product("RTX 3060", "85 999 ₽", "/Images/2.jpg"),
        new Product("RTX 6600", "49 999 ₽", "/Images/3.jpg"),
        new Product("RTX 3050", "35 999 ₽", "/Images/4.jpg"),
        new Product("RTX 3080 Ti", "108 999 ₽", "/Images/5.jpg"),
        new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
         new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
        new Product("RTX 3060", "85 999 ₽", "/Images/2.jpg"),
        new Product("RTX 6600", "49 999 ₽", "/Images/3.jpg"),
        new Product("RTX 3050", "35 999 ₽", "/Images/4.jpg"),
        new Product("RTX 3080 Ti", "108 999 ₽", "/Images/5.jpg"),
        new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
        new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
        new Product("RTX 3060", "85 999 ₽", "/Images/2.jpg"),
        new Product("RTX 6600", "49 999 ₽", "/Images/3.jpg"),
        new Product("RTX 3050", "35 999 ₽", "/Images/4.jpg"),
        new Product("RTX 3080 Ti", "108 999 ₽", "/Images/5.jpg"),
        new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
         new Product("RTX 3080", "85 999 ₽", "/Images/1.jpg"),
        new Product("RTX 3060", "85 999 ₽", "/Images/2.jpg"),
        new Product("RTX 6600", "49 999 ₽", "/Images/3.jpg")
        };
    }
    private void Button_Click(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }

    private void Window_MouseDown(object sender, MouseButtonEventArgs e)
    {
        DragMove();
    }
}
